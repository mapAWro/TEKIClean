package teki.clean.app.domain.dto;

import java.util.ArrayList;

import teki.clean.app.domain.Schedules;

public class ScheduleDTO {
	private ArrayList<Schedules> scheduleses = new ArrayList<Schedules>();
	
}
