package teki.clean.app.service;

import teki.clean.app.domain.Customers;
import teki.clean.app.domain.Orders;


/**
 * @author Jacek
 * Realizuje wszelkie funkcjonalno�ci klienta.
 */
public class CustomerManager {
	Customers customer;	
	Orders order;
	
}
