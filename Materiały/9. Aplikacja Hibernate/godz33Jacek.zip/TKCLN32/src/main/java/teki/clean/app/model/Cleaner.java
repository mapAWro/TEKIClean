package teki.clean.app.model;

public class Cleaner {
	private int cleaner_id;
	private int user_id;

	public int getCleaner_id() 					{return cleaner_id;}
	public void setCleaner_id(int cleaner_id) 	{this.cleaner_id = cleaner_id;}
	
	public int getUser_id() 					{return user_id;}
	public void setUser_id(int user_id) 		{this.user_id = user_id;}

}
