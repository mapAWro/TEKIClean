package teki.clean.app.service;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import teki.clean.app.model.User;

/** Klasa pomocnicza przeznaczona do wydobywania danych z bazy
 * @author Jacek
 *
 */
class DBConnector {
	private Session currentSession;
	
	public DBConnector(){
		
	}
	
	public Session openCurrentSession() {
		currentSession = getSessionFactory().openSession();
		return currentSession;
	}
	
	public void closeCurrentSession() {
		currentSession.close();
	}
	
	private static SessionFactory getSessionFactory() {
		Configuration configuration = new Configuration().configure("hibernate.cfg.xml");
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder()
				.applySettings(configuration.getProperties());
		SessionFactory sessionFactory = configuration.buildSessionFactory(builder.build());
		return sessionFactory;
	}
	
	public Session getCurrentSession() {
		return currentSession;
	}
	
	public void setCurrentSession(Session currentSession) {
		this.currentSession = currentSession;
	}
	
	@SuppressWarnings("unchecked")
	public List<User> getUsers() {
		List<User> users = (List<User>) getCurrentSession().createCriteria(User.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return users;
	}
}

/** Klasa weryfikuje u�ytkownika na podstawie jego loginu i has�a
 * @author Jacek
 *
 */
public class LoginHelper {

	DBConnector dbc;
	
	public LoginHelper(){
		dbc = new DBConnector();
	}
	
	/** Pobiera list� u�ytkownik�w z bazy
	 * @return lista u�ytkownik�w
	 */
	private List<User> getUsers(){
		dbc.openCurrentSession();
        List<User> users = dbc.getUsers();
        dbc.closeCurrentSession();
        
        return users;
	}
	
	/**
	 * Szuka u�ytkownika na podstawie loginu
	 * @param login - login u�ytkownika
	 * @return user - u�ytkownik spe�niaj�cy podany parametr 
	 */
	private User findUser( String login ){

		User desiredUser = null;
		for( User user : getUsers() ){
			if( user.getLogin().equals(login) ){
				desiredUser = user;
				break;
			}
		}
		
		return desiredUser;
	}
	
	/** Sprawdza zgodno�� hase�
	 * @param userPassword - has�o podane przez u�ytkownika
	 * @param Password - has�o przechowywane w bazie
	 * @return true - has�o takie samo
	 */
	private boolean checkPassword( String userPassword, String Password){
		/*hash calculation*/
		String hash = userPassword;
		if ( userPassword.equals(Password) )
			return true;
		else
			return false;
	}
	
	/**Weryfikuje u�ytkownika na podstawie podanego loginu i has�a
	 * @param userLogin
	 * @param userPassword
	 * @return true - u�ytkownik poda� prawid�owe dane
	 */
	public boolean verifyUser( String userLogin, String userPassword){
		boolean response = false;
		User user = findUser(userLogin);
		if ( user != null ){
			String dbPassword = user.getPassword();
			response = checkPassword( userPassword, dbPassword );
		}
		return response;
	}
}
