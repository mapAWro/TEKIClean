package teki.clean.app.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.transaction.annotation.Transactional;

import teki.clean.app.service.LoginHelper;

public class CustomAuthenticationProvider implements AuthenticationProvider {
 	
	@Transactional
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		
		//User details = userDao.getUser(authentication.getName());
		System.out.println("1");
        String login = authentication.getName(); //login
        System.out.println("1");
        String password = authentication.getCredentials().toString(); //haslo
        System.out.println("1");
        
        /*Weryfikacja u�ytkownika*/
        LoginHelper lh = new LoginHelper();
        boolean isOK = lh.verifyUser(login, password);
        
        System.out.println("1");
        
        if ( isOK ) {
            List<GrantedAuthority> grantedAuths = new ArrayList();
            grantedAuths.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
            Authentication auth = new UsernamePasswordAuthenticationToken(login, password, grantedAuths);
            return auth;
        } else {
            return null;
        }
    }
 
    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }
    
}
