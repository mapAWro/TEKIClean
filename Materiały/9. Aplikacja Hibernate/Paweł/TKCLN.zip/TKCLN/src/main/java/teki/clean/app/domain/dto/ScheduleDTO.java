package teki.clean.app.domain.dto;

import java.util.ArrayList;

import teki.clean.app.domain.Schedules;

public class ScheduleDTO {
	
	public ScheduleDTO( ArrayList<Schedules> schedules ){
		this.schedules = schedules;
	}
	
	private ArrayList<Schedules> schedules;
	
	public ArrayList<Schedules> getSchedules() {
		return schedules;
	}
	public void setSchedules(ArrayList<Schedules> schedules) {
		this.schedules = schedules;
	}

}
