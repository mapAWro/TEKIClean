package teki.clean.app.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import teki.clean.app.domain.Offers;
import teki.clean.app.domain.Users;
import teki.clean.app.domain.dto.CleanerFormDTO;
import teki.clean.app.domain.dto.ScheduleDTO;
import teki.clean.app.service.CleanerManager;
import teki.clean.app.service.UserManager;

@Controller
@Scope("session")
@SessionAttributes("userManager")
public class CleanerController {
	private UserManager um;
	private CleanerManager cm;
		
	@RequestMapping(value = "/cleanerPanel", method = RequestMethod.GET)
	public String cleanerMain(@ModelAttribute("userManager")UserManager um_, ModelMap model) {
		um = um_;
		cm = new CleanerManager( um.getUser() );
		
		CleanerFormDTO cleanerData = new CleanerFormDTO();
		cleanerData.setData( cm, um.getUser() );
		model.addAttribute( "cleanerData", cleanerData );
		return "cleanerPanel";
   }
	
	@RequestMapping(value = "/schedule", method = RequestMethod.GET)
	public String scheduleMain(ModelMap model) {
		model.addAttribute( "schedule", cm.getSchedules() );
		return "schedule";
   }
	
	@RequestMapping(value = "/scheduleEdit", method = RequestMethod.GET)
	public ModelAndView scheduleEditForm(ModelMap model) {
		return new ModelAndView( "scheduleEdit", "command", new ScheduleDTO( cm.getSchedules() ) );
   }
	
	@RequestMapping(value = "/scheduleEdit", method = RequestMethod.POST)
	public String scheduleEditSubmit(ScheduleDTO sch, ModelMap model) {
		model.addAttribute( "schedule", sch.getSchedules() );
		cm.setSchedules(sch.getSchedules());
		return "schedule";
   }
	
	@RequestMapping(value = "/addOffer", method = RequestMethod.GET)
	public ModelAndView addOfferForm(ModelMap model) {
		return new ModelAndView( "addOffer", "command", new Offers() );
   }
	
	@RequestMapping(value = "/addOffer", method = RequestMethod.POST)
	public String addOfferSubmit(Offers offer, ModelMap model) {
		model.addAttribute( "offer", offer );
		cm.addOffer(offer);
		return "addOfferResult";
   }
	
	@RequestMapping(value = "/myOffers", method = RequestMethod.GET)
	public String offers(ModelMap model) {
		model.addAttribute( "offersList", cm.getOffers() );
		return "myOffers";
   }
	
	@RequestMapping(value = "/offerEdit/*", method = RequestMethod.GET)
	public ModelAndView offerEditForm(HttpServletRequest request, ModelMap model) {
		//Pobranie id oferty z odebranego zapytania klienta
		String[] OfferReqParam = request.getRequestURI().split("/");
		Integer offerId = Integer.parseInt( OfferReqParam[OfferReqParam.length - 1] );
		return new ModelAndView( "offerEdit", "command", cm.getOffer(offerId) );
   }
	
	@RequestMapping(value = "/offerEdit", method = RequestMethod.POST)
	public String offerEditSubmit(Offers offer, ModelMap model) {
		model.addAttribute( "offer", offer );
		return "myOffers";
   }
	
	@RequestMapping(value = "/cleanerEdit", method = RequestMethod.GET)
	public ModelAndView cleanerEditForm(ModelMap model) {		
		return new ModelAndView( "cleanerEdit", "command", um.getUser() );
   }
	
	@RequestMapping(value = "/cleanerEdit", method = RequestMethod.POST)
	public String cleanerEditSubmit(Users user, ModelMap model) {
		model.addAttribute( "userData", user );
		return "cleanerPanel";
   }
}
