package teki.clean.app.service;

public class ResourcesManager {

}
