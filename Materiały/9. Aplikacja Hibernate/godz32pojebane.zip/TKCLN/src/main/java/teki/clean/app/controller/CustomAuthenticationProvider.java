package teki.clean.app.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;




import teki.clean.app.dao.UserDAO;
import teki.clean.app.model.User;

@Controller
public class CustomAuthenticationProvider implements AuthenticationProvider {
 
	@Autowired
	UserDAO userDao;
	
	@Transactional
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		
		//User details = userDao.getUser(authentication.getName());
		System.out.println("1");
        String name = authentication.getName(); //login
        System.out.println("1");
        String password = authentication.getCredentials().toString(); //haslo
        System.out.println("1");
        
        User user = userDao.get(1);
        System.out.println("1");
        
        if (name.equals("kon") && password.equals("rad")) {
            List<GrantedAuthority> grantedAuths = new ArrayList();
            grantedAuths.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
            Authentication auth = new UsernamePasswordAuthenticationToken(name, password, grantedAuths);
            return auth;
        } else {
            return null;
        }
    }
 
    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }
}
