package teki.clean.app.controller;

import java.util.List;

import teki.clean.app.dao.ScheduleDAO;
import teki.clean.app.model.Schedule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * Handles requests for the application home page.
 */

@Controller
public class ScheduleListController {
	@Autowired
	private ScheduleDAO scheduleDao;
	
	@RequestMapping(value="/Schedule")
	public ModelAndView kutas() {
		List<Schedule> listSchedules = scheduleDao.list();
		ModelAndView model = new ModelAndView("ScheduleList");
		model.addObject("scheduleList", listSchedules);
		return model;
	}
}
