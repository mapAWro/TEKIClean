package teki.clean.app.controller;

import java.util.List;

import teki.clean.app.dao.CustomerDAO;
import teki.clean.app.model.Customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * Handles requests for the application home page.
 */

@Controller
public class CustomerListController {
	@Autowired
	private CustomerDAO customerDao;
	
	@RequestMapping(value="/Customer")
	public ModelAndView kutas() {
		List<Customer> listCustomers = customerDao.list();
		ModelAndView model = new ModelAndView("CustomerList");
		model.addObject("customerList", listCustomers);
		return model;
	}
}
