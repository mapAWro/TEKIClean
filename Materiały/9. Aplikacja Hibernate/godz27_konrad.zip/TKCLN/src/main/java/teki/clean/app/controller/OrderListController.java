package teki.clean.app.controller;

import java.util.List;

import teki.clean.app.dao.OrderDAO;
import teki.clean.app.model.Order;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * Handles requests for the application home page.
 */

@Controller
public class OrderListController {
	@Autowired
	private OrderDAO orderDao;
	
	@RequestMapping(value="/Order")
	public ModelAndView kutas() {
		List<Order> listOrders = orderDao.list();
		ModelAndView model = new ModelAndView("OrderList");
		model.addObject("orderList", listOrders);
		return model;
	}
}
