package teki.clean.app.controller;

import java.util.List;

import teki.clean.app.dao.OpinionDAO;
import teki.clean.app.model.Opinion;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * Handles requests for the application home page.
 */

@Controller
public class OpinionListController {
	@Autowired
	private OpinionDAO opinionDao;
	
	@RequestMapping(value="/UOpinion")
	public ModelAndView kutas() {
		List<Opinion> listOpinions = opinionDao.list();
		ModelAndView model = new ModelAndView("OpinionList");
		model.addObject("opinionList", listOpinions);
		return model;
	}
}
