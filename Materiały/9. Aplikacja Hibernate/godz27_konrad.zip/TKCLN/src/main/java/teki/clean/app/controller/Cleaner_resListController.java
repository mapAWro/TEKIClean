package teki.clean.app.controller;

import java.util.List;

import teki.clean.app.dao.Cleaner_resDAO;
import teki.clean.app.model.Cleaner_res;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * Handles requests for the application home page.
 */

@Controller
public class Cleaner_resListController {
	@Autowired
	private Cleaner_resDAO cleaner_resDao;
	
	@RequestMapping(value="/Cleaner_res")
	public ModelAndView kutas() {
		List<Cleaner_res> listCleaner_ress = cleaner_resDao.list();
		ModelAndView model = new ModelAndView("Cleaner_resList");
		model.addObject("cleaner_resList", listCleaner_ress);
		return model;
	}
}
