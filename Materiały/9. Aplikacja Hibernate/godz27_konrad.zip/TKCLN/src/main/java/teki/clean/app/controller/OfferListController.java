package teki.clean.app.controller;

import java.util.List;

import teki.clean.app.dao.OfferDAO;
import teki.clean.app.model.Offer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * Handles requests for the application home page.
 */

@Controller
public class OfferListController {
	@Autowired
	private OfferDAO offerDao;
	
	@RequestMapping(value="/Offer")
	public ModelAndView kutas() {
		List<Offer> listOffers = offerDao.list();
		ModelAndView model = new ModelAndView("OfferList");
		model.addObject("offerList", listOffers);
		return model;
	}
}
