package teki.clean.app.domain.dto;

public class OrderDTO {
	private String date;
	private String time;
	private boolean module;
	private boolean room;
	private boolean removal;
	
	private Integer offerId;
	
	public OrderDTO( Integer offerId ){
		this.offerId = offerId;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public boolean isModule() {
		return module;
	}
	public void setModule(boolean module) {
		this.module = module;
	}
	public boolean isRoom() {
		return room;
	}
	public void setRoom(boolean room) {
		this.room = room;
	}
	public boolean isRemoval() {
		return removal;
	}
	public void setRemoval(boolean removal) {
		this.removal = removal;
	}
}
