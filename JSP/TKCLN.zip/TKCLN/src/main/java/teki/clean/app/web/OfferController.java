package teki.clean.app.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import teki.clean.app.domain.Orders;
import teki.clean.app.service.CustomerManager;
import teki.clean.app.service.UserManager;

@Controller
@Scope("session")
@SessionAttributes("userManager")
public class OfferController {
	private UserManager um;
	private CustomerManager cstm;
	
	@RequestMapping(value = "/offers", method = RequestMethod.GET)
	public String offers(@ModelAttribute("userManager")UserManager um_, ModelMap model) {
		um = um_;
		cstm = new CustomerManager( um.getUser() );
		model.addAttribute( "offersList", um.getAllOffers() );
		return "offers";
   }
	
	@RequestMapping(value = "/offerDetails/*", method = RequestMethod.GET)
	public String offerDetails(HttpServletRequest request, ModelMap model) {
		String page = "userNotLogged";
		
		/*Rozwi�zanie prowizoryczne*/
		if(um.getUser() != null){
			String[] OfferReqParam = request.getRequestURI().split("/");
			Integer offerId = Integer.parseInt( OfferReqParam[OfferReqParam.length - 1] );
			model.addAttribute( "offerInfo", um.getOfferDetails( offerId ) );
			page = "offerDetails";
		}
		
		return page;
   }
	
	@RequestMapping(value = "/MakeOrder/*", method = RequestMethod.GET)
	public ModelAndView customerMakeOrderForm(HttpServletRequest request, ModelMap model) {
		
		String[] OfferReqParam = request.getRequestURI().split("/");
		Integer offerId = Integer.parseInt( OfferReqParam[OfferReqParam.length - 1] );
		Orders order = new Orders();
		order.setOffers( um.getOfferDetails( offerId ) );
		
		return new ModelAndView( "customerMakeOrder", "command", order );
   }
	
	@RequestMapping(value = "/customerMakeOrder", method = RequestMethod.POST)
	public String customerMakeOrderSubmit(Orders order, ModelMap model) {
		cstm.makeOrder(order, order.getOffers().getOfferId() );
		return "customerMakeOrderResult";
   }
}
